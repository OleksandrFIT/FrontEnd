let x = prompt ("Input any number");

if (x < 0) {
    console.log("Your number is negative");
} else if (x > 0) {
    console.log("Your number is positive");
} else {
    console.log("Your number is zero");
}