let x = prompt ("Write first number: ");
let y = prompt ("Write first second: ");

res = x * y;

let z = null;

while(z != res){
    z = prompt ("Enter the result of an expression: " + x + " * " + y + " = ");
}